<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class SubscriptionAlreadyExistException extends MnsException
{
}

?>
