<?php
//mysql database address
define('DB_HOST','127.0.0.1');
//mysql database user
define('DB_USER','news_19aq_com');
//database password
define('DB_PASSWD','rbGxZkxWLieEdd5Y');
//database name
define('DB_NAME','news_19aq_com');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','ZN!BCQ)ftvIV(AU%huj(ZbK118gyhOBQeb59e3c716501684fad3d61d747fdfc0');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_zS3HJInCaYu7m5j3d9dPfGj5L2J5NgFq');
